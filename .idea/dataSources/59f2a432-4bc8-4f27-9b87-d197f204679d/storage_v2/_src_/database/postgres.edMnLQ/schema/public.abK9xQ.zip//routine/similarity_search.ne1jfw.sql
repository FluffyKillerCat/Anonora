create function similarity_search(query_embedding vector, match_threshold double precision, match_count integer)
    returns TABLE(id uuid, title character varying, description text, similarity double precision)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        documents.id,
        documents.title,
        documents.description,
        1 - (documents.vector_embedding <=> query_embedding) AS similarity
    FROM documents
    WHERE documents.vector_embedding IS NOT NULL
    AND 1 - (documents.vector_embedding <=> query_embedding) > match_threshold
    ORDER BY documents.vector_embedding <=> query_embedding
    LIMIT match_count;
END;
$$;

alter function similarity_search(vector, double precision, integer) owner to postgres;

grant execute on function similarity_search(vector, double precision, integer) to anon;

grant execute on function similarity_search(vector, double precision, integer) to authenticated;

grant execute on function similarity_search(vector, double precision, integer) to service_role;

