create function get_accessible_documents(user_uuid uuid)
    returns TABLE(id uuid, title character varying, description text, tags text[], status character varying, created_at timestamp with time zone)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT DISTINCT
        d.id,
        d.title,
        d.description,
        d.tags,
        d.status,
        d.created_at
    FROM documents d
    LEFT JOIN document_shares ds ON d.id = ds.document_id
    WHERE d.owner_id = user_uuid OR ds.shared_with_user_id = user_uuid;
END;
$$;

alter function get_accessible_documents(uuid) owner to postgres;

grant execute on function get_accessible_documents(uuid) to anon;

grant execute on function get_accessible_documents(uuid) to authenticated;

grant execute on function get_accessible_documents(uuid) to service_role;

